import 'package:flutter/material.dart';
import '../screens/welcome/splash_screen.dart';

var customRoutes = <String, WidgetBuilder>{

  '/splashscreen': (context) => const SplashScreen(),

};