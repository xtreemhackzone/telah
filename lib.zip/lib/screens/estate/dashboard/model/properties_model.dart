class PropertyUnits {
  String address;
  String propertyType;

  PropertyUnits(
      {required this.address, required this.propertyType,});
}